int random();
void strReverseW(LPWSTR str);
LRESULT CALLBACK msgBoxHook(int, WPARAM, LPARAM);